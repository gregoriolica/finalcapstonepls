<?php
// Admin Management Page for:
//   - Registering new doctors, clerks, and midwives
//   - Editing doctor schedules
//   - Editing doctor list
//   - Editing service amounts

// NOTE: This is a PHP-based admin page. 
// Database connection removed for UI testing.
// For demo, this uses simple PHP arrays and POST handling.

session_start();

// Database connection removed for UI testing
// $host = 'localhost';
// $dbname = 'medstaff_dbo';
// $username = 'root'; 
// $password = '';

// try {
//     $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
//     $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// } catch(PDOException $e) {
//     die("Connection failed: " . $e->getMessage());
// }

// --- DEMO DATA (Replace with DB queries in production) ---
$users = isset($_SESSION['admin_users']) ? $_SESSION['admin_users'] : [
    ['id'=>1, 'name'=>'Dr. Maria Santos', 'role'=>'doctor', 'specialization'=>'OB-GYN', 'schedule'=>'Mon-Fri 8AM-5PM'],
    ['id'=>2, 'name'=>'Juan Dela Cruz', 'role'=>'clerk'],
    ['id'=>3, 'name'=>'Ana Midwife', 'role'=>'midwife'],
];
$services = isset($_SESSION['admin_services']) ? $_SESSION['admin_services'] : [
    ['id'=>1, 'name'=>'Pre-Natal Check Up', 'amount'=>500],
    ['id'=>2, 'name'=>'Normal Delivery', 'amount'=>5000],
    ['id'=>3, 'name'=>'Pedia Check Up', 'amount'=>400],
    ['id'=>4, 'name'=>'Papsmear', 'amount'=>800],
    ['id'=>5, 'name'=>'Family Planning', 'amount'=>300],
    ['id'=>6, 'name'=>'BCG/HEPA-B Vaccine', 'amount'=>600],
    ['id'=>7, 'name'=>'Newborn Screening', 'amount'=>1200],
    ['id'=>8, 'name'=>'Hearing Test', 'amount'=>350],
    ['id'=>9, 'name'=>'Post Partum Check Up', 'amount'=>450],
    ['id'=>10, 'name'=>'Immunization', 'amount'=>200],
    ['id'=>11, 'name'=>'Doctor Fee', 'amount'=>200],
];

// --- HANDLE FORM SUBMISSIONS ---
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Register new user (Database functionality removed for UI testing)
    if (isset($_POST['register_user'])) {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $role = $_POST['role'];
        
        // Validation
        if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm_password)) {
            $error_message = 'Please fill in all fields.';
        } elseif ($password !== $confirm_password) {
            $error_message = 'Passwords do not match.';
        } else {
            // Database functionality removed - just show success message for UI testing
            $success_message = 'Medical staff registered successfully! (Database connection disabled for UI testing)';
        }
    }

    // Edit doctor schedule
    if (isset($_POST['edit_schedule'])) {
        foreach ($users as &$user) {
            if ($user['role'] === 'doctor' && isset($_POST['schedule_'.$user['id']])) {
                $user['schedule'] = $_POST['schedule_'.$user['id']];
            }
        }
        $_SESSION['admin_users'] = $users;
        $msg = "Doctor schedules updated!";
    }

    // Edit doctor list (delete doctor)
    if (isset($_POST['delete_doctor_id'])) {
        $users = array_filter($users, function($u) {
            return $u['id'] != $_POST['delete_doctor_id'];
        });
        $_SESSION['admin_users'] = $users;
        $msg = "Doctor deleted!";
    }

    // Edit service amounts
    if (isset($_POST['edit_services'])) {
        foreach ($services as &$service) {
            if (isset($_POST['service_amount_'.$service['id']])) {
                $service['amount'] = floatval($_POST['service_amount_'.$service['id']]);
            }
        }
        $_SESSION['admin_services'] = $services;
        $msg = "Service amounts updated!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Management Panel</title>
    <meta charset="UTF-8">
    <style>
        body { background: #f3f4f6; }
        #admin-management-page { max-width: 1100px; margin: 40px auto; background: #fff; border-radius: 18px; box-shadow: 0 8px 32px rgba(44,62,80,0.10); padding: 36px 40px 40px 40px; font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }
        h1 { font-size: 2.2rem; color: #2d0b3a; margin-bottom: 28px; font-weight: 800; letter-spacing: -1px; }
        .admin-flex { display: flex; gap: 32px; flex-wrap: wrap; }
        .admin-col { flex: 1 1 340px; min-width: 340px; }
        .admin-card { background: #f8fafc; border-radius: 14px; padding: 28px 24px 24px 24px; margin-bottom: 32px; border: 1px solid #e5e7eb; }
        .admin-table { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
        .admin-table th, .admin-table td { padding: 10px 12px; border-bottom: 1px solid #e5e7eb; text-align: left; }
        .admin-table th { background: #f3f4f6; font-weight: 700; }
        .admin-btn { background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color: #fff; border: none; border-radius: 8px; padding: 8px 18px; font-size: 15px; font-weight: 600; cursor: pointer; margin-right: 6px; }
        .admin-btn-danger { background: #ef4444; }
        .admin-btn:disabled { opacity: 0.6; cursor: not-allowed; }
        .admin-input, .admin-select { width: 100%; padding: 8px 10px; border-radius: 6px; border: 1px solid #e5e7eb; font-size: 15px; margin-top: 4px; }
        .admin-label { font-weight: 500; color: #4b5563; }
        .admin-success { color: #059669; font-weight: 600; margin-bottom: 12px; }
    </style>
</head>
<body>
<div id="admin-management-page">
    <!-- Navigation Breadcrumb -->
    <div style="margin-bottom: 20px; display: flex; align-items: center; gap: 12px;">
        <a href="mwdash.php" style="display: inline-flex; align-items: center; gap: 8px; color: #667eea; text-decoration: none; font-weight: 600; padding: 8px 16px; border-radius: 8px; background: #f8fafc; border: 1px solid #e2e8f0; transition: all 0.3s ease;" onmouseover="this.style.background='#e2e8f0'; this.style.transform='translateY(-1px)'" onmouseout="this.style.background='#f8fafc'; this.style.transform='translateY(0)'">
            <span>←</span>
            <span>Back to Dashboard</span>
        </a>
        <div style="color: #9ca3af; font-size: 14px;">|</div>
        <div style="color: #64748b; font-size: 14px; font-weight: 500;">Admin Management</div>
    </div>
    
    <!-- Admin Header -->
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #f1f5f9;">
        <div>
            <h1 style="margin: 0; font-size: 2.2rem; color: #2d0b3a; font-weight: 800; letter-spacing: -1px;">Admin Management Panel</h1>
            <p style="margin: 8px 0 0 0; color: #64748b; font-size: 1rem;">Manage users, schedules, and service configurations</p>
        </div>
        <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                👑
            </div>
        </div>
    </div>
    <?php if (!empty($error_message)): ?>
        <div style="background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; padding: 12px; border-radius: 8px; margin-bottom: 20px;"><?=htmlspecialchars($error_message)?></div>
    <?php endif; ?>
    
    <?php if (!empty($success_message)): ?>
        <div style="background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 12px; border-radius: 8px; margin-bottom: 20px;"><?=htmlspecialchars($success_message)?></div>
    <?php endif; ?>
    <div class="admin-flex">
        <!-- Left: User Registration -->
        <div class="admin-col">
            <div class="admin-card">
                <h2 style="font-size: 1.25rem; color: #3b3b3b; font-weight: 700; margin-bottom: 18px;">Register New User</h2>
                <form method="post" autocomplete="off">
                    <div style="margin-bottom: 14px;">
                        <label class="admin-label">First Name</label>
                        <input type="text" name="first_name" class="admin-input" required>
                    </div>
                    <div style="margin-bottom: 14px;">
                        <label class="admin-label">Last Name</label>
                        <input type="text" name="last_name" class="admin-input" required>
                    </div>
                    <div style="margin-bottom: 14px;">
                        <label class="admin-label">Email</label>
                        <input type="email" name="email" class="admin-input" required>
                    </div>
                    <div style="margin-bottom: 14px;">
                        <label class="admin-label">Password</label>
                        <input type="password" name="password" class="admin-input" required>
                    </div>
                    <div style="margin-bottom: 14px;">
                        <label class="admin-label">Confirm Password</label>
                        <input type="password" name="confirm_password" class="admin-input" required>
                    </div>
                    <div style="margin-bottom: 14px;">
                        <label class="admin-label">Role</label>
                        <select name="role" class="admin-select" id="role-select" required onchange="toggleDoctorFields()">
                            <option value="">Select role</option>
                            <option value="doctor">Doctor</option>
                            <option value="clerk">Clerk</option>
                            <option value="midwife">Midwife</option>
                        </select>
                    </div>
                    <div id="doctor-fields" style="display:none;">
                        <div style="margin-bottom: 14px;">
                            <label class="admin-label">Specialization</label>
                            <input type="text" name="specialization" class="admin-input">
                        </div>
                        <div style="margin-bottom: 14px;">
                            <label class="admin-label">Schedule</label>
                            <input type="text" name="schedule" class="admin-input" placeholder="e.g. Mon-Fri 8AM-5PM">
                        </div>
                    </div>
                    <button type="submit" name="register_user" class="admin-btn">Register</button>
                </form>
            </div>
        </div>
        <!-- Right: Management Panels -->
        <div class="admin-col">
            <!-- Doctor Schedules -->
            <div class="admin-card">
                <h2 style="font-size: 1.1rem; color: #3b3b3b; font-weight: 700; margin-bottom: 14px;">Edit Doctor Schedules</h2>
                <form method="post">
                    <table class="admin-table">
                        <tr>
                            <th>Name</th>
                            <th>Specialization</th>
                            <th>Schedule</th>
                        </tr>
                        <?php foreach ($users as $user): if ($user['role'] === 'doctor'): ?>
                        <tr>
                            <td><?=htmlspecialchars($user['name'])?></td>
                            <td><?=htmlspecialchars($user['specialization'])?></td>
                            <td>
                                <input type="text" name="schedule_<?=$user['id']?>" class="admin-input" value="<?=htmlspecialchars($user['schedule'])?>">
                            </td>
                        </tr>
                        <?php endif; endforeach; ?>
                    </table>
                    <button type="submit" name="edit_schedule" class="admin-btn">Save Schedules</button>
                </form>
            </div>
            <!-- Doctor List -->
            <div class="admin-card">
                <h2 style="font-size: 1.1rem; color: #3b3b3b; font-weight: 700; margin-bottom: 14px;">Edit Doctor List</h2>
                <table class="admin-table">
                    <tr>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>Action</th>
                    </tr>
                    <?php foreach ($users as $user): if ($user['role'] === 'doctor'): ?>
                    <tr>
                        <td><?=htmlspecialchars($user['name'])?></td>
                        <td><?=htmlspecialchars($user['specialization'])?></td>
                        <td>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="delete_doctor_id" value="<?=$user['id']?>">
                                <button type="submit" class="admin-btn admin-btn-danger" onclick="return confirm('Delete this doctor?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endif; endforeach; ?>
                </table>
            </div>
            <!-- Service Amounts -->
            <div class="admin-card">
                <h2 style="font-size: 1.1rem; color: #3b3b3b; font-weight: 700; margin-bottom: 14px;">Edit Service Amounts</h2>
                <form method="post">
                    <table class="admin-table">
                        <tr>
                            <th>Service</th>
                            <th>Amount (₱)</th>
                        </tr>
                        <?php foreach ($services as $service): ?>
                        <tr>
                            <td><?=htmlspecialchars($service['name'])?></td>
                            <td>
                                <input type="number" name="service_amount_<?=$service['id']?>" class="admin-input" min="0" step="0.01" value="<?=htmlspecialchars($service['amount'])?>">
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                    <button type="submit" name="edit_services" class="admin-btn">Save Amounts</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Admin Footer -->
    <div style="margin-top: 40px; padding-top: 30px; border-top: 2px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
        <div style="display: flex; align-items: center; gap: 20px;">
            <a href="mwdash.php" style="display: inline-flex; align-items: center; gap: 8px; color: #667eea; text-decoration: none; font-weight: 600; padding: 10px 20px; border-radius: 10px; background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%); border: 1px solid #d1d5db; transition: all 0.3s ease;" onmouseover="this.style.background='linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%)'; this.style.transform='translateY(-2px)'" onmouseout="this.style.background='linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)'; this.style.transform='translateY(0)'">
                <span>🏠</span>
                <span>Dashboard</span>
            </a>
            <div style="color: #9ca3af; font-size: 14px;">•</div>
            <div style="color: #64748b; font-size: 14px;">Admin Panel v1.0</div>
        </div>
        <div style="color: #9ca3af; font-size: 12px;">
            Last updated: <?=date('M d, Y H:i')?>
        </div>
    </div>
</div>
<script>
function toggleDoctorFields() {
    var role = document.getElementById('role-select').value;
    document.getElementById('doctor-fields').style.display = (role === 'doctor') ? 'block' : 'none';
}
</script>
</body>
</html>

